<link rel="stylesheet" type="text/css" href="./css/hms-block.css">

    <ul class="ul-links">
        <li><a href="#" class="nav admin">Hospital Management System</a></li>
        <li><a href="contact.php" class="nav-css">Contact Us</a></li>
        <li><a href="#" class="nav-css">Testimonial</a></li>
        <li><a href="aboutus.php" class="nav-css">About Us</a></li>
        <li><a href="index.php" class="nav-css">Home</a></li>
    </ul>

    <div class="block text-center">
        <div class="block-content justify-content-center">
            <h1>Hospital Management System</h1>
        </div>
    </div>

    <br> <br>
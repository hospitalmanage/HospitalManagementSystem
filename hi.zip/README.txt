Hospital Managemet System

Files should be used while developing each PAGE

# Required Things(Compulsary) {
	Indentations : 4 spaces only
	Code-Quality : Maintained;
}

# Navigation Bar should be present in each PAGE
# Block should be present in each PAGE
# Font of whole Page : Courier New
# Font-size of whole Page : 14px
# Color of the boxes : #160424
# Color of the block : #160424
# Hovering Effect should be present in each Box {
	
	Text-Color : White
	Background-Color : #160424

	# While Active Tab in Navigation Bar {

		Background-Color : #0e0217
		Text-Color : White
		# There should be No Text Decoration(Help) IMP.
		Please Make Sure that You are comforatble with this 
		# If not than Please Ask Shrey or Ronak for further applicable
	}
}


# Font should be used : Courier New


    Request Page :-

    Name of all the fields :-

    1) fname	    
    2) lname	    
    3) mobile	    
    4) address	    
    5) mail		    
    6) occupation   
    7) aadhar		
